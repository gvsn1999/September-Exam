﻿using ExamAppEF.Models.DTOs;
using ExamAppEF.Service.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ExamAppEF.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeService _employeeService;

        public EmployeeController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }

        [HttpGet]
        [Route("GetAllEmployees")]
        public IEnumerable<EmployeeDTO> GetEmployees()
        {
            return (IEnumerable<EmployeeDTO>)_employeeService.GetEmployees();
        }

        [HttpGet]
        [Route("GetEmployeeById")]
        public IActionResult GetEmployeeById(int id)
        {
            EmployeeDTO employee = _employeeService.GetEmployeeById(id);

            if (employee == null)
            {
                return NotFound("Employee with that id does not exist!");
            }

            return Ok(employee);
        }

        [HttpDelete("RemoveEmployee/{id:int}")]
        public IActionResult Delete([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                return Ok(_employeeService.DeleteEmployee(id));
            }
            return BadRequest();
        }

        [HttpPost("AddEmployee")]
        public IActionResult Post([FromBody] EmployeeDTO employee)
        {
            if (ModelState.IsValid)
            {
                var newEmployee = _employeeService.AddEmployee(employee);
                return Created($"Employee with id {newEmployee.Id} is created", newEmployee.Id);
            }

            return UnprocessableEntity(ModelState);
        }

        [HttpPut("UpdateEmployee/{id:int}")]
        public IActionResult Put([FromRoute] int id, [FromBody] EmployeeDTO employee)
        {
            if (ModelState.IsValid)
            {
                employee.Id = id;
                var result = _employeeService.UpdateEmployee(employee);

                if (result != null)
                    return Ok(result);
                else
                    return NoContent();
            }
            return BadRequest();
        }
    }

}
