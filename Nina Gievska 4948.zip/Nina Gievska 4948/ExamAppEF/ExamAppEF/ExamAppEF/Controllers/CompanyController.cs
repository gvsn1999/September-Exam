﻿using ExamAppEF.Models.DTOs;
using ExamAppEF.Service.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace ExamAppEF.WebApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService _companyService;

        public CompanyController(ICompanyService companyService)
        {
            _companyService = companyService;
        }

        [HttpGet]
        [Route("GetAllCompanies")]
        public IEnumerable<CompanyDTO> GetCompanies()
        {
            return _companyService.GetCompanies();
        }

        [HttpGet]
        [Route("GetCompanyById")]
        public IActionResult GetCompanyById(int id)
        {
            CompanyDTO company = _companyService.GetCompanyById(id);

            if (company == null)
            {
                return NotFound("Company with that id does not exist!");
            }

            return Ok(company);
        }

        [HttpDelete("RemoveCompany/{id:int}")]
        public IActionResult Delete([FromRoute] int id)
        {
            if (ModelState.IsValid)
            {
                return Ok(_companyService.DeleteCompany(id));
            }
            return BadRequest();
        }

        [HttpPost("AddCompany")]
        public IActionResult Post([FromBody] CompanyDTO company)
        {
            if (ModelState.IsValid)
            {
                var newCompany = _companyService.AddCompany(company);
                return Created($"Company with id {newCompany.Id} is created", newCompany.Id);
            }

            return UnprocessableEntity(ModelState);
        }

        [HttpPut("UpdateCompany/{id:int}")]
        public IActionResult Put([FromRoute] int id, [FromBody] CompanyDTO company)
        {
            if (ModelState.IsValid)
            {
                company.Id = id;
                var result = _companyService.UpdateCompany(company);

                if (result != null)
                    return Ok(result);
                else
                    return NoContent();
            }
            return BadRequest();
        }
    }

}
