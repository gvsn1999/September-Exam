﻿using ExamAppEF.Data.Entities;
using ExamAppEF.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;


namespace ExamAppEF.Data.Repositories
{
    public class CompanyRepository : ICompanyRepository
    {
        private readonly DataContext _dataContext;

        public CompanyRepository(DataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public void AddCompany(Company newCompany)
        {
            _dataContext.Companies.Add(newCompany);
            Save();
        }

        public bool DeleteCompany(Company company)
        {
            try
            {
                _dataContext.Companies.Remove(company);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Company GetCompanyById(int id)
        {
            return _dataContext.Companies.Include(c => c.Employees).FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Company> GetCompanies()
        {
            return _dataContext.Companies.Include(c => c.Employees);
        }

        public void UpdateCompany(Company oldCompany, Company newCompany)
        {
            _dataContext.Entry(oldCompany).CurrentValues.SetValues(newCompany);
            Save();
        }

        public void Save()
        {
            _dataContext.SaveChangesAsync();
        }

    }
}
