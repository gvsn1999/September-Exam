﻿using ExamAppEF.Data.Entities;
using ExamAppEF.Data.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ExamAppEF.Data.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly DataContext _dataContext;

        public EmployeeRepository(DataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public void AddEmployee(Employee newemployee)
        {
            _dataContext.Employees.Add(newemployee);
            Save();
        }

        public bool DeleteEmployee(Employee employee)
        {
            try
            {
                _dataContext.Employees.Remove(employee);
                Save();
                return true;
            }
            catch
            {
                return false;
            }
        }

        public Employee GetEmployeeById(int id)
        {
            return _dataContext.Employees.Include(g => g.Company).FirstOrDefault(x => x.Id == id);
        }

        public IEnumerable<Employee> GetEmployees()
        {
            return _dataContext.Employees.Include(g => g.Company);
        }

        public void UpdateEmployee(Employee oldEmployee, Employee newEmployees)
        {
            _dataContext.Entry(oldEmployee).CurrentValues.SetValues(newEmployees);
            Save();
        }

        public void Save()
        {
            _dataContext.SaveChangesAsync();
        }

    }
}



