﻿using Microsoft.EntityFrameworkCore.SqlServer.Infrastructure.Internal;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using ExamAppEF.Data.Entities;

namespace ExamAppEF.Data
{

    public class DataContext : DbContext
    {
        private readonly string _connStr;

        public DataContext(DbContextOptions<DataContext> options)
        {

            SqlServerOptionsExtension sqlServerOptionsExtension = options.FindExtension<SqlServerOptionsExtension>();


            if (sqlServerOptionsExtension != null)
            {
                _connStr = sqlServerOptionsExtension.ConnectionString;
            }
        }

        public virtual DbSet<Employee> Employees { get; set; }
        public virtual DbSet<Company> Companies { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_connStr, providerOptions => providerOptions.CommandTimeout(60));
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Company>(entry =>
            {
                entry.HasKey(e => e.Id);

                entry.Property(e => e.Name)
                    .IsRequired(true)
                    .HasColumnType("varchar(255)");

                entry.Property(e => e.Address)
                    .IsRequired(true)
                    .HasColumnType("varchar(255)");

                entry.Property(e => e.Owner)
                    .IsRequired(true)
                    .HasColumnType("varchar(255)");

                entry.Property(e => e.Year)
                    .IsRequired(true)
                    .HasColumnType("int");

                entry.Property(e => e.NumberOfEmployees)
                    .IsRequired(true)
                    .HasColumnType("int");

                entry.HasMany(c => c.Employees)
            .WithOne(e => e.Company)
            .HasForeignKey(e => e.CompanyId);

            });

            modelBuilder.Entity<Employee>(entry =>
            {
                entry.HasKey(e => e.Id);

                entry.Property(e => e.FirstName)
                    .IsRequired(true)
                    .HasColumnType("varchar(100)");

                entry.Property(e => e.LastName)
                    .IsRequired(true)
                    .HasColumnType("varchar(200)");

                entry.Property(e => e.Address)
                    .IsRequired(true)
                    .HasColumnType("varchar(300)");

                entry.Property(e => e.DOB)
                    .IsRequired(true)
                    .HasColumnType("datetime");

                entry.Property(e => e.EmploymentStartDate)
                    .IsRequired(true)
                    .HasColumnType("datetime");

                entry.Property(e => e.TotalCompensation)
                    .IsRequired(true)
                    .HasColumnType("decimal(18,2)");

                entry.Property(e => e.NoticePeriod)
                    .IsRequired(true)
                    .HasColumnType("varchar(100)");

                entry.Property(e => e.CompanyId)
                    .IsRequired(true)
                    .HasColumnType("int");

                entry.HasOne(e => e.Company)
                    .WithMany(c => c.Employees)
                    .HasForeignKey(e => e.CompanyId);

            });

            modelBuilder.Entity<Company>().HasData(
    new Company
    {
        Id = 1,
        Name = "TechCorp",
        Address = "123 Tech Street",
        Owner = "John Doe",
        Year = 2000,
        NumberOfEmployees = 5
    },

    new Company
    {
        Id = 2,
        Name = "DevSoft",
        Address = "456 Code Avenue",
        Owner = "Jane Smith",
        Year = 2005,
        NumberOfEmployees = 10
    },

    new Company
    {
        Id = 3,
        Name = "NetSolutions",
        Address = "789 Solution Blvd",
        Owner = "Robert Brown",
        Year = 2010,
        NumberOfEmployees = 15
    }
);
            modelBuilder.Entity<Employee>().HasData(
                new Employee
                {
                    Id = 1,
                    FirstName = "Alice",
                    LastName = "Johnson",
                    DOB = new System.DateTime(1990, 1, 1),
                    Address = "123 Main Street",
                    EmploymentStartDate = new System.DateTime(2010, 1, 10),
                    TotalCompensation = 50000,
                    NoticePeriod = "1 Month",
                    CompanyId = 1
                },

                new Employee
                {
                    Id = 2,
                    FirstName = "Bob",
                    LastName = "Williams",
                    DOB = new System.DateTime(1985, 2, 2),
                    Address = "456 Elm Street",
                    EmploymentStartDate = new System.DateTime(2009, 2, 5),
                    TotalCompensation = 55000,
                    NoticePeriod = "2 Months",
                    CompanyId = 2
                },

                new Employee
                {
                    Id = 3,
                    FirstName = "Charlie",
                    LastName = "Davis",
                    DOB = new System.DateTime(1980, 3, 3),
                    Address = "789 Oak Street",
                    EmploymentStartDate = new System.DateTime(2008, 3, 15),
                    TotalCompensation = 60000,
                    NoticePeriod = "3 Months",
                    CompanyId = 3
                }
            );

        }
    }
}
