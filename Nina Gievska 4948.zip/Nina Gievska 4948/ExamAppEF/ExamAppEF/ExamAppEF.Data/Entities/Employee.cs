﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace ExamAppEF.Data.Entities
{
    public class Employee
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(200)]
        public string LastName { get; set; }
        [Required]
        public DateTime DOB { get; set; }
        [Required]
        [MaxLength(300)]
        public string Address { get; set; }
        [Required]
        public DateTime EmploymentStartDate { get; set; }
        [Required]
        public double TotalCompensation { get; set; }
        [Required]
        public string NoticePeriod { get; set; }

        public int CompanyId { get; set; }
        public virtual Company Company { get; set; }

    }
}

