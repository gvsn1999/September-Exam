﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ExamAppEF.Data.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Companies",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "varchar(255)", nullable: false),
                    Address = table.Column<string>(type: "varchar(255)", nullable: false),
                    Owner = table.Column<string>(type: "varchar(255)", nullable: false),
                    Year = table.Column<int>(type: "int", nullable: false),
                    NumberOfEmployees = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Companies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "varchar(100)", maxLength: 100, nullable: false),
                    LastName = table.Column<string>(type: "varchar(200)", maxLength: 200, nullable: false),
                    DOB = table.Column<DateTime>(type: "datetime", nullable: false),
                    Address = table.Column<string>(type: "varchar(300)", maxLength: 300, nullable: false),
                    EmploymentStartDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    TotalCompensation = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    NoticePeriod = table.Column<string>(type: "varchar(100)", nullable: false),
                    CompanyId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Employees_Companies_CompanyId",
                        column: x => x.CompanyId,
                        principalTable: "Companies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Companies",
                columns: new[] { "Id", "Address", "Name", "NumberOfEmployees", "Owner", "Year" },
                values: new object[] { 1, "123 Tech Street", "TechCorp", 5, "John Doe", 2000 });

            migrationBuilder.InsertData(
                table: "Companies",
                columns: new[] { "Id", "Address", "Name", "NumberOfEmployees", "Owner", "Year" },
                values: new object[] { 2, "456 Code Avenue", "DevSoft", 10, "Jane Smith", 2005 });

            migrationBuilder.InsertData(
                table: "Companies",
                columns: new[] { "Id", "Address", "Name", "NumberOfEmployees", "Owner", "Year" },
                values: new object[] { 3, "789 Solution Blvd", "NetSolutions", 15, "Robert Brown", 2010 });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Address", "CompanyId", "DOB", "EmploymentStartDate", "FirstName", "LastName", "NoticePeriod", "TotalCompensation" },
                values: new object[] { 1, "123 Main Street", 1, new DateTime(1990, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2010, 1, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), "Alice", "Johnson", "1 Month", 50000m });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Address", "CompanyId", "DOB", "EmploymentStartDate", "FirstName", "LastName", "NoticePeriod", "TotalCompensation" },
                values: new object[] { 2, "456 Elm Street", 2, new DateTime(1985, 2, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2009, 2, 5, 0, 0, 0, 0, DateTimeKind.Unspecified), "Bob", "Williams", "2 Months", 55000m });

            migrationBuilder.InsertData(
                table: "Employees",
                columns: new[] { "Id", "Address", "CompanyId", "DOB", "EmploymentStartDate", "FirstName", "LastName", "NoticePeriod", "TotalCompensation" },
                values: new object[] { 3, "789 Oak Street", 3, new DateTime(1980, 3, 3, 0, 0, 0, 0, DateTimeKind.Unspecified), new DateTime(2008, 3, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), "Charlie", "Davis", "3 Months", 60000m });

            migrationBuilder.CreateIndex(
                name: "IX_Employees_CompanyId",
                table: "Employees",
                column: "CompanyId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "Companies");
        }
    }
}
