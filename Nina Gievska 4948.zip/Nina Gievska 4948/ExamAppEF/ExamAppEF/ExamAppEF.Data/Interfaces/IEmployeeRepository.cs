﻿using ExamAppEF.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Data.Interfaces
{

        public interface IEmployeeRepository
        {
            IEnumerable<Employee> GetEmployees();
            Employee GetEmployeeById(int id);
            void AddEmployee(Employee employee);
            void UpdateEmployee(Employee oldEmployee, Employee employees);
            bool DeleteEmployee(Employee employee);


        }
    }


