﻿using ExamAppEF.Data.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Data.Interfaces
{
    public interface ICompanyRepository
    {
        IEnumerable<Company> GetCompanies();
        Company GetCompanyById(int id);
        void AddCompany(Company company);
        void UpdateCompany(Company oldCompany, Company companies);
        bool DeleteCompany(Company company);


    }
}


