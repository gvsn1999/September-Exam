﻿using ExamAppEF.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Service.Interfaces
{
    public interface IEmployeeService
    {
        IEnumerable<EmployeeDTO> GetEmployees();
        EmployeeDTO GetEmployeeById(int id);
        EmployeeDTO AddEmployee(EmployeeDTO employee);
        EmployeeDTO UpdateEmployee(EmployeeDTO employee);
        bool DeleteEmployee(int id);
    }

}
