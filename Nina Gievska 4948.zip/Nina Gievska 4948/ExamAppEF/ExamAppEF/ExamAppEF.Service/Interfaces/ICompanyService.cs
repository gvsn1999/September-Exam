﻿using ExamAppEF.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Service.Interfaces
{

    public interface ICompanyService
    {
        IEnumerable<CompanyDTO> GetCompanies();
        CompanyDTO GetCompanyById(int id);
        CompanyDTO AddCompany(CompanyDTO company);
        CompanyDTO UpdateCompany(CompanyDTO company);
        bool DeleteCompany(int id);
    }


}
