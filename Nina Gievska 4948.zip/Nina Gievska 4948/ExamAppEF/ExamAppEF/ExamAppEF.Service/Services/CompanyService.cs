﻿using AutoMapper;
using ExamAppEF.Data.Entities;
using ExamAppEF.Data.Interfaces;
using ExamAppEF.Models.DTOs;
using ExamAppEF.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Service.Services
{
    public class CompanyService : ICompanyService
    {
        private readonly IMapper _mapper;
        private readonly ICompanyRepository _companyRepository;

        public CompanyService(ICompanyRepository companyRepository, IMapper mapper)
        {
            _companyRepository = companyRepository;
            _mapper = mapper;
        }

        public IEnumerable<CompanyDTO> GetCompanies()
        {
            var companies = _companyRepository.GetCompanies();
            return _mapper.Map<IEnumerable<CompanyDTO>>(companies);
        }

        public CompanyDTO GetCompanyById(int id)
        {
            var company = _companyRepository.GetCompanyById(id);
            return _mapper.Map<CompanyDTO>(company);
        }

        public CompanyDTO AddCompany(CompanyDTO company)
        {
            Company newCompany = _mapper.Map<Company>(company);

            if (_companyRepository.GetCompanyById(company.Id) == null)
            {
                _companyRepository.AddCompany(newCompany);
            }
            return _mapper.Map<CompanyDTO>(newCompany);
        }

        public CompanyDTO UpdateCompany(CompanyDTO company)
        {
            Company newCompany = _mapper.Map<Company>(company);
            Company oldCompany = _companyRepository.GetCompanyById(newCompany.Id);

            if (oldCompany != null)
            {
                _companyRepository.UpdateCompany(oldCompany, newCompany);
            }
            return _mapper.Map<CompanyDTO>(newCompany);
        }

        public bool DeleteCompany(int id)
        {
            var companyEntity = _companyRepository.GetCompanyById(id);
            return _companyRepository.DeleteCompany(companyEntity);
        }
    }

}
