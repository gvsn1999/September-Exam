﻿using AutoMapper;
using ExamAppEF.Data.Entities;
using ExamAppEF.Data.Interfaces;
using ExamAppEF.Models.DTOs;
using ExamAppEF.Service.Interfaces;
using System.Collections.Generic;

namespace ExamAppEF.Service.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IMapper _mapper;
        private readonly IEmployeeRepository _employeeRepository;
        private object employeeRepo;
        private IMapper mapper;

        public EmployeeService(IEmployeeRepository employeeRepository, IMapper mapper)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }

        public EmployeeService(object employeeRepo, IMapper mapper)
        {
            this.employeeRepo = employeeRepo;
            this.mapper = mapper;
        }

        public IEnumerable<EmployeeDTO> GetEmployees()
        {
            var employees = _employeeRepository.GetEmployees();
            return _mapper.Map<IEnumerable<EmployeeDTO>>(employees);
        }

        public EmployeeDTO GetEmployeeById(int id)
        {
            var employee = _employeeRepository.GetEmployeeById(id);
            return _mapper.Map<EmployeeDTO>(employee);
        }

        public EmployeeDTO AddEmployee(EmployeeDTO employee)
        {
            Employee newEmployee = _mapper.Map<Employee>(employee);

            if (_employeeRepository.GetEmployeeById(employee.Id) == null)
            {
                _employeeRepository.AddEmployee(newEmployee);
            }
            return _mapper.Map<EmployeeDTO>(newEmployee);
        }

        public EmployeeDTO UpdateEmployee(EmployeeDTO employee)
        {
            Employee newEmployee = _mapper.Map<Employee>(employee);
            Employee oldEmployee = _employeeRepository.GetEmployeeById(newEmployee.Id);

            if (oldEmployee != null)
            {
                _employeeRepository.UpdateEmployee(oldEmployee, newEmployee);
            }
            return _mapper.Map<EmployeeDTO>(newEmployee);
        }

        public bool DeleteEmployee(int id)
        {
            var employeeEntity = _employeeRepository.GetEmployeeById(id);
            return _employeeRepository.DeleteEmployee(employeeEntity);
        }
    }

}
