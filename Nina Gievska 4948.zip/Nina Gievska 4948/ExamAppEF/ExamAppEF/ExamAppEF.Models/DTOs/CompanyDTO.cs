﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Models.DTOs
{
    public class CompanyDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string Owner { get; set; }
        public int Year { get; set; }
        public int NumberOfEmployees { get; set; }

        public List<EmployeeDTO> Employees { get; set; }
    }
}
