﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Models.DTOs
{
    public class EmployeeDTO
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Address { get; set; }
        public DateTime EmploymentStartDate { get; set; }
        public decimal TotalCompensation { get; set; }
        public string NoticePeriod { get; set; }

        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
    }


}
