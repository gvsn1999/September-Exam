﻿using AutoMapper;
using ExamAppEF.Data.Entities;
using ExamAppEF.Models.DTOs;
using System;
using System.Collections.Generic;
using System.Text;

namespace ExamAppEF.Models.Profiles
{
    public class EmployeeProfile : Profile
    {
        public EmployeeProfile()
        {
            CreateMap<Employee, EmployeeDTO>()
                .ReverseMap();
        }
    }
}